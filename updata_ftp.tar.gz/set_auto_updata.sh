#!/bin/bash
sed -i "1a /opt/spice/mftp" /etc/rc.local&&\
mkdir /opt/spice&&cp mftp config.ftp /opt/spice&&\
echo "set_auto_updata sucessful"

