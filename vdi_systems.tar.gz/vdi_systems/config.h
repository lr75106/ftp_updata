#ifndef _CONFIG_H_
#define _CONFIG_H_
#define MAX_LINE_LEN 210
char *read_config(FILE *fp, char *key);
int add_config(FILE *fp, char *key, char *value);
#endif