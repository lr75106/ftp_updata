rm -rf start
gcc start.c config.c -o start `pkg-config --cflags --libs gtk+-3.0` >/dev/null 2>&1
ls star*
