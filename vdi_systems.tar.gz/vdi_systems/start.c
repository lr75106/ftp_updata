//gcc start.c -o start `pkg-config --cflags --libs gtk+-3.0` >/dev/null 2>&1
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include<locale.h>
#include <glib/gi18n.h>
#include <stdio.h>
#include <sys/stat.h>
#include <termios.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<signal.h>
#include<pthread.h>
#include <arpa/inet.h>
#include <sys/types.h>        
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <glib/gconvert.h>
#include  <gdk/gdkkeysyms.h>
#include "config.h"
#include <signal.h> 
GtkWidget *window; //���崰��
GtkWidget *fixed;//�̶���������
GtkLabel *EditId,*EditPwd,*EditIp,*EditPort;
GtkLabel *LabelId,*LabelPwd,*LabelMAC;
GtkWidget *ButtonLogin,*ButtonShutdown,*ButtonSave,*ButtonCancel,*ButtonSet,*ButtonIpSet,*ButtonNext;
GtkLabel *LabelTips;
//��ѡ����
//GSList *ButtonGroup1,*ButtonGroup2;
GtkWidget *ButtonIpAuto,*ButtonIpStatic,*ButtonIpMAC;
GtkWidget *Hbox; 
   
int LoginFailedFlag=0;
void* Pthread_LabelUpdateText(void *argv);
void* Pthread_LoginUpdateText(void *argv);
void* Pthread_CheckConnect(void *argv);
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
int CheckConnect(char *dst, int cnt);
static char buff[500];

//���ṹ
struct Package
{
	//����
	int Len;
	//��������
	int Cmd;
};

struct Login_Info
{
	char ID[0x20]; //0x20 32BYTE���ȣ�20�ĳ���̫����Щ��
	char PWD[0x20];
	char SN[0x30]; 
};
struct Configuration_Info
{
	char IP[20]; 
	char PORT[20];
	char PWD[20];
	char UUID[40];
};

struct Status_Info
{
	char IP[20]; 
	char UUID[40];
};

//��¼��
struct LoginPackage
{
	struct Package Head;
	struct Login_Info Info;
};
//��¼-���ð�
struct ConfigurationPackage
{
	struct Package Head;
	struct Configuration_Info Info;
};

//״̬��
struct StatusPackage
{
	struct Package Head;
	struct Status_Info Info;
};
//״̬-���ð�
struct StatusInfoPackage
{
	struct Package Head;
	char Status;
};

struct Configuration_Info Config;

char *toutf8(char *String)
{
    return g_convert(String,-1,"UTF-8","GB2312",NULL,NULL,NULL);
} 

/************************�ŵ����������ļ�******************************/

int is_valid_ip(const char *ip) 
{ 
    int section = 0;  //ÿһ�ڵ�ʮ����ֵ 
    int dot = 0;       //������ָ��� 
    int last = -1;     //ÿһ������һ���ַ� 
    while(*ip)
    { 
        if(*ip == '.')
        { 
            dot++; 
            if(dot > 3)
            { 
                return 0; 
            } 
            if(section >= 0 && section <=255)
            { 
                section = 0; 
            }else{ 
                return 0; 
            } 
        }else if(*ip >= '0' && *ip <= '9')
        { 
            section = section * 10 + *ip - '0'; 
            //if(last == '0')
           // { 
           //     return 0; 
           // } 
        }else{ 
            return 0; 
        } 
        last = *ip; 
        ip++;        
    }

    if(section >= 0 && section <=255)
    { 
        if(3 == dot)
        {
        section = 0; 
        printf ("IP address success!\n");
        return 1;
       }
    } 
    return 0; 
}

void clean_string(char * const str)//����ַ����س����пհ� 
{
	char *start = str;
	char *end;
	char *p = str;
	while(*p) {
		switch(*p) {
			case ' ':
			case '\r':
			case '\n':
			if(str != start) {
				*start = *p;
				start++;
			}
			break;
			default:
			*start = *p;
			start++;
			end = start;
		}
		p++;
	}
	*end = '\0';
}

int GetIP( char recvBuf[] )//��ȡIP
{
	 	FILE *stream;  
    stream = popen("ifconfig | awk 'BEGIN{FS=\"[: \t]+\"}{if($1==\"eth0\")next;exit}END{print $4}' ", "r");  
    fread(recvBuf, sizeof(char), (size_t)stream, stream); 
    clean_string(recvBuf); 
    pclose(stream);
		return 0;
}

int GetIpType()
{
	 	FILE *stream; 
	 	char recvBuf[50]; 
    stream = popen("cat /etc/network/interfaces |grep address", "r");  
    int ret=fread(recvBuf, sizeof(char), (size_t)stream, stream);  
    pclose(stream);
    if( 0 == ret)
			return 0;//��̬
		else
			return 1;//��̬
}

int AutoGetIP(viod)
{	
		system("echo \"auto lo\niface lo inet loopback\" > /tmp/interfaces");
		system("echo linkosky |sudo -S cp -a /tmp/interfaces /etc/network/interfaces");
		system("echo linkosky |sudo -S service network-manager restart"); 
}

int GetGateway( char recvBuf[] )//����
{
	 	FILE *stream;  
    stream = popen("ip route show |awk -F \" \" 'NR==1''{print $3}'", "r"); 
    fread(recvBuf, sizeof(char), (size_t)stream, stream);
    clean_string(recvBuf);  
    pclose(stream);
		return 0;
}

int GetNetMask( char recvBuf[] )//����
{
	 	FILE *stream; 
	 	char buff[25];
	 	memset(buff,0,sizeof(buff));
    stream = popen("ifconfig | grep 'inet' | awk -F \" \" 'NR==1''{print $4}'", "r"); 
    fread(buff, sizeof(char), (size_t)stream, stream);
    memcpy(recvBuf,buff+7,sizeof(buff));
    clean_string(recvBuf);  
    pclose(stream);
		return 0;
}

int GetDNS( char recvBuf[] )
{
	 	FILE *stream; 
    stream = popen("cat /etc/resolv.conf | grep nameserver |awk -F \" \" 'NR==1''{print $2}'", "r"); 
    fread(recvBuf, sizeof(char), (size_t)stream, stream);  
    pclose(stream);
    clean_string(recvBuf); 
		return 0;
}

int SetIP(char *address,char *gateway,char *netmask,char *dns)
{	
		char buff[1000];
		memset(buff,0,sizeof(buff));
		sprintf(buff,"echo \"auto lo\n\
iface lo inet loopback\n\
auto eth0\n\
iface eth0 inet static\n\
address %s\n\
gateway %s\n\
netmask %s\n\
dns-nameservers %s\" > /tmp/interfaces",address,gateway,netmask,dns);
		system(buff);
		system("echo linkosky |sudo -S cp -a /tmp/interfaces /etc/network/interfaces"); 
		system("echo linkosky |sudo -S reboot");
		//system("echo linkosky |sudo -S ifdown eth0 && ifup eth0"); 
		return 0;
}
int GetMAC( char recvBuf[] )
{
	 	FILE *stream;  
    stream = popen("ifconfig | grep 'Link' | awk -F \" \" 'NR==1''{print $5}'", "r");  
    fread(recvBuf, sizeof(char), (size_t)stream, stream);  
    pclose(stream);
    clean_string(recvBuf);
		return 0;
}
int GetSerialNumber( char recvBuf[] )//Ӳ�̱��
{
	 	FILE *stream; 
    stream = popen("echo linkosky |sudo -S hdparm -I /dev/sda |grep 'Serial Number'|awk -F \" \" 'NR==1''{print $3}'", "r"); 
    fread(recvBuf, sizeof(char), (size_t)stream, stream);  
    pclose(stream);
    clean_string(recvBuf);
		return 0;
}
/************************************************************************/


int GetVmStatus(char *IP,char *UUID)//Cmd=0xC0
{
		//printf("IP=%s,UUID=%s\r\n",IP,UUID);
		int LenTemp;
		struct StatusPackage StaPac;
		struct StatusInfoPackage StaInfo;
		char buff[100];	
			
		int sockfd=socket(AF_INET,SOCK_STREAM,0);
		struct sockaddr_in servaddr;
		memset(&servaddr, 0, sizeof(servaddr));
		servaddr.sin_family = AF_INET; 
		servaddr.sin_port = htons(atoi(gtk_entry_get_text(EditPort)));
		servaddr.sin_addr.s_addr = inet_addr(gtk_entry_get_text(EditIp));
		//printf("PORT=%d,IP=%s\r\n",atoi(gtk_entry_get_text(EditPort)),gtk_entry_get_text(EditIp));
		if( connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) ==-1)
		{  
			printf("connect failed\r\n");
			return -1;
	  }
	  else
		{
		  memset(&StaPac,0,sizeof(StaPac));
		  StaPac.Head.Cmd=0xC0;
		  memcpy(StaPac.Info.IP, IP,strlen(IP));		  
		  strncpy(StaPac.Info.UUID,UUID,36);
		  
		  //printf("%s|%s\r\n",StaPac.Info.IP,StaPac.Info.UUID);
		  StaPac.Head.Len=sizeof(StaPac)-4;
		  write(sockfd, &StaPac, sizeof(StaPac));	
			recv(sockfd, &LenTemp, 4,0);
			memset(buff,0,sizeof(buff));
			recv(sockfd, buff, LenTemp,0);
			int t=close(sockfd);
			//printf("t=%d\r\n",t);
			int Cmd;
			memcpy(&Cmd,buff,4);  
			switch(Cmd)
			{
					case 0xC1:
							printf("case 0xC1\r\n");
    					memset(&StaInfo,0,sizeof(StaInfo));
							memcpy(&StaInfo,buff-4,sizeof(StaInfo));
    					//printf("Status=%c\r\n",StaInfo.Status);
    					if( StaInfo.Status == 'R')
    						return 1;
    					else
    						return 0;
							break;
					default:
							printf("Failure\r\n");
							break;	
			}
		}
		return -1;
}


void Pthread_GetVmStatus(void * arg)
{
	struct Configuration_Info *Info;
	Info = (struct Configuration_Info*)arg;
	
	//printf("IP=%s|UUID=%s\r\n",Info->IP,Info->UUID);
	printf("Pthread_GetVmStatus\r\n");
	sleep(4);
	int i;
	for(i=0;i<60;i++)
	{
		sleep(1);
		if ( 1 == GetVmStatus(Info->IP,Info->UUID ) )
			break;
	}
	if( i < 60 )
	{	
		if((fork()) == 0)
		{
			memset(buff,0,sizeof(buff));
			sprintf(buff,"echo linkosky |sudo -S spicy -h %s -p %s -w %s --spice-usbredir-redirect-on-connect=\"0x03,-1,-1,-1,0|-1,-1,-1,-1,1\"",Info->IP,Info->PORT,Info->PWD);
			system(buff);
			exit(0);
		}			
		else
			g_thread_create((GThreadFunc)Pthread_CheckConnect, Config.IP, FALSE, NULL);
	}else
	{//��¼��ʱ
			printf("login timeouts\r\n");
	}	  
								
}

void ButtonLogin_clicked (GtkWidget *button,gpointer data)
{
	pthread_mutex_lock(&mutex);
	gtk_widget_set_sensitive(ButtonLogin,0);
	FILE *fp=fopen("/lib/vdi_systems/settings.ini","r+");
	if(fp != NULL)
	{	
		gtk_entry_set_text(EditIp,read_config(fp,"Ip"));
		gtk_entry_set_text(EditPort,read_config(fp,"Port"));
		fclose(fp);	
		if( CheckConnect( gtk_entry_get_text(EditIp) , 5) ) 
		{	
			g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#FF0000\" font_desc='18'>���粻ͨ�����Ժ����ԣ���%d��</span>", FALSE, NULL);
			gtk_entry_set_text(EditPwd, "");
			gtk_widget_set_sensitive(ButtonLogin,1);
			pthread_mutex_unlock(&mutex);
			return;		
		}
		int sockfd=socket(AF_INET,SOCK_STREAM,0);
		struct sockaddr_in servaddr;
		memset(&servaddr, 0, sizeof(servaddr));
		servaddr.sin_family = AF_INET; 
		servaddr.sin_port = htons(atoi(gtk_entry_get_text(EditPort)));
		servaddr.sin_addr.s_addr = inet_addr(gtk_entry_get_text(EditIp));
		if( connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) ==-1)
		{  
			g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#FF0000\" font_desc='18'>����δ���У����Ժ����ԣ���%d��</span>", FALSE, NULL); 
	  }
	  else
		{
		  int LenTemp;
		  struct LoginPackage Login;
		  memset(&Login,0,sizeof(Login));
		  Login.Head.Cmd=0xA0;
		  memcpy(Login.Info.ID, gtk_entry_get_text(EditId), gtk_entry_get_text_length(EditId) );
		  memcpy(Login.Info.PWD, gtk_entry_get_text(EditPwd),gtk_entry_get_text_length(EditPwd));
		  char Buff[30];
		  memset( Buff , 0 , sizeof(Buff) );
 		  GetSerialNumber( Buff );//Ӳ�̱��
		  memcpy(Login.Info.SN, Buff,strlen(Buff));//sn
		  Login.Head.Len=sizeof(Login)-4;
		  write(sockfd, &Login, sizeof(Login));
		  //printf("---1-\r\n");	
			recv(sockfd, &LenTemp, 4,0);
			//printf("---2-\r\n");	
			memset(buff,0,sizeof(buff));
			recv(sockfd, buff, LenTemp,0);
			//printf("---3-\r\n");	
			close(sockfd);
			//printf("r=%d\r\n",r);
			int Cmd;
			memcpy(&Cmd,buff,4);  
			switch(Cmd)
			{
					case 0xA1:
							memset(&Config,0,sizeof(Config));
							memcpy(&Config,buff+4,sizeof(Config));
							
							g_thread_create((GThreadFunc)Pthread_LoginUpdateText, NULL, FALSE, NULL);							
							//Config.IP,Config.PORT,Config.PWD Config.UUID
							//printf("Config.UUID=%s\r\n",Config.UUID);
							
							g_thread_create((GThreadFunc)Pthread_GetVmStatus, &Config, FALSE, NULL);	
						  

							break;
					default:
							g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#FF0000\" font_desc='18'>�������󣬵�¼ʧ�ܣ����Ժ����ԣ���%d��</span>", FALSE, NULL); 					
							break;	
			}
		}	
	}
	else
	{
		//δ���ò���
		g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#FF0000\" font_desc='18'>δ������������������ú����ԣ���%d��</span>", FALSE, NULL); 
	}
	gtk_entry_set_text(EditPwd, "");
	gtk_widget_set_sensitive(ButtonLogin,1);
	pthread_mutex_unlock(&mutex);
	return;
}

void ButtonShutdown_clicked (GtkWidget *button,gpointer data)
{
	exit(1);
	//system("echo linkosky |sudo -S shutdown -h now >/dev/null 2>&1");
}

void ButtonSet_clicked (GtkWidget *button,gpointer data)
{	
	gtk_label_set_text(LabelId,"IP:"); 
	gtk_label_set_text(LabelPwd,"Port:");
	FILE *fp=fopen("/lib/vdi_systems/settings.ini","r+");
	gtk_entry_set_max_length(EditPort,6);
	if(fp != NULL)
	{	
		gtk_entry_set_text(EditIp,read_config(fp,"Ip"));
		gtk_entry_set_text(EditPort,read_config(fp,"Port"));
		fclose(fp);		
	}
	gtk_widget_hide(ButtonSet);
	gtk_widget_hide(ButtonIpSet); 
	gtk_widget_hide(EditId); 
	gtk_widget_hide(EditPwd);
	gtk_widget_hide(ButtonLogin);
	gtk_widget_hide(ButtonShutdown);
	gtk_widget_show(EditIp); 
	gtk_widget_show(EditPort);
	gtk_widget_show(ButtonSave); 
	gtk_widget_show(ButtonCancel); 
	return;
}

void ButtonIpSet_clicked (GtkWidget *button,gpointer data)
{	
	gtk_label_set_text(LabelId,""); 
	gtk_label_set_text(LabelPwd,"IP:");
	
	char IpBuff[20];
	memset(IpBuff,0,sizeof(IpBuff));
	GetIP(IpBuff);
	gtk_entry_set_max_length(EditPort,15);	
	gtk_entry_set_text(EditPort,IpBuff);
	
	if( GetIpType() ==1 )
	{//��̬IP
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ButtonIpStatic),TRUE);
	}else
	{//��̬IP
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ButtonIpAuto),TRUE);
		gtk_widget_set_sensitive(EditPort,FALSE);
	}
	
	gtk_widget_hide(ButtonSet);
	gtk_widget_hide(ButtonIpSet); 
	gtk_widget_hide(EditId); 
	gtk_widget_hide(EditPwd);
	gtk_widget_hide(ButtonLogin);
	gtk_widget_hide(ButtonShutdown);
	gtk_widget_show(Hbox); 
	gtk_widget_show(EditPort);
	gtk_widget_show(ButtonNext); 
	gtk_widget_show(ButtonCancel); 
	return;
}
void ButtonGroup_clicked (GtkWidget *button,gpointer data)
{
	char Buff[25];
	memset(Buff,0,sizeof(Buff));
	if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ButtonIpAuto)))
	{
		gtk_widget_set_sensitive(EditPort,FALSE);
		gtk_label_set_text(LabelPwd,"IP:");
		GetIP(Buff);
		gtk_entry_set_max_length(EditPort,15);	
		gtk_entry_set_text(EditPort,Buff);	
	}else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ButtonIpStatic)))
	{
		gtk_widget_set_sensitive(EditPort,1);
		gtk_label_set_text(LabelPwd,"IP:");
		GetIP(Buff);
		gtk_entry_set_max_length(EditPort,15);	
		gtk_entry_set_text(EditPort,Buff);
	}else
	{
		gtk_widget_set_sensitive(EditPort,FALSE);
		//gtk_label_set_text(LabelPwd,"MAC:");
		//GetMAC(Buff);	
		gtk_label_set_text(LabelPwd,toutf8("Number:"));
		GetSerialNumber(Buff);
		gtk_entry_set_max_length(EditPort,20);
		gtk_entry_set_text(EditPort,Buff);
	}
}

struct IPV4
{
	char IP[16];
	char Gateway[16];
	char NetMask[16];
	char DNS[16];
};
 
static struct IPV4 IpConfig;
int ButtonNext_clicked(GtkWidget *button,gpointer data)
{
	if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ButtonIpAuto)))
	{
		//�Զ���ȡ 
		gtk_widget_set_sensitive(ButtonNext,0);
		UpdateSetLabel();	 
		g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#1BA1E2\" font_desc='18'>���ڻ�ȡ���磬���Ժ򣡣�%d��</span>", FALSE, NULL); 
		AutoGetIP();
		gtk_widget_set_sensitive(ButtonNext,1);
	}else
	{
		//��̬IP ��һ��
		if( 0 == is_valid_ip(gtk_entry_get_text(EditPort)))//IP���
			return; 
		char IpBuff[25];
		memset(IpBuff,0,sizeof(IpBuff));
		if( 0 == memcmp( gtk_label_get_text(LabelPwd),"IP",2) )
		{ 
			gtk_label_set_text(LabelPwd,"Gateway:");
			gtk_widget_set_sensitive(ButtonIpStatic,FALSE);
			gtk_widget_set_sensitive(ButtonIpAuto,FALSE);
			gtk_widget_set_sensitive(ButtonIpMAC,FALSE);
			memset(&IpConfig,0,sizeof(IpConfig));
			
			memcpy(IpConfig.IP,gtk_entry_get_text(EditPort),gtk_entry_get_text_length(EditPort));
			
			GetGateway(IpBuff);	
			gtk_entry_set_text(EditPort,IpBuff);
		}
		else if( 0 == memcmp( gtk_label_get_text(LabelPwd),"Gateway",2) )//����
		{
			gtk_label_set_text(LabelPwd,"NetMask:");
			
			memcpy(IpConfig.Gateway,gtk_entry_get_text(EditPort),gtk_entry_get_text_length(EditPort));
				
			GetNetMask(IpBuff);	
			gtk_entry_set_text(EditPort,IpBuff);
		}
		else if( 0 == memcmp( gtk_label_get_text(LabelPwd),"NetMask",2) )//����
		{
			gtk_label_set_text(LabelPwd,"DNS:");
			
			memcpy(IpConfig.NetMask,gtk_entry_get_text(EditPort),gtk_entry_get_text_length(EditPort));
			
			GetDNS(IpBuff);	
			gtk_entry_set_text(EditPort,IpBuff);
		}
		else if( 0 == memcmp( gtk_label_get_text(LabelPwd),"DNS",2) )
		{
			//����
			memcpy(IpConfig.DNS,gtk_entry_get_text(EditPort),gtk_entry_get_text_length(EditPort));
			
			UpdateSetLabel();
			g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#1BA1E2\" font_desc='18'>�������������Ժ򣡣�%d��</span>", FALSE, NULL); 
			SetIP(IpConfig.IP,IpConfig.Gateway,IpConfig.NetMask,IpConfig.DNS);
		}
		else if( 0 == memcmp( gtk_label_get_text(LabelPwd),"Number",3) )
		{
			UpdateSetLabel();
		}
	}
}

void EditId_Pwd_Signal(GtkWidget *button,gpointer data)
{
	if( gtk_entry_get_text_length(EditId)>0 && gtk_entry_get_text_length(EditPwd)>0 )
	{
			gtk_widget_set_sensitive(ButtonLogin,1);
	}
	else
		gtk_widget_set_sensitive(ButtonLogin,FALSE);
}

void EditIpPort_Signal(GtkWidget *button,gpointer data)
{
	if( gtk_entry_get_text_length(EditIp)>6 && gtk_entry_get_text_length(EditPort)>3 )
	{
			gtk_widget_set_sensitive(ButtonSave,1);
	}
	else
		gtk_widget_set_sensitive(ButtonSave,0);
}

void EditId_Pwd_Enter(GtkWidget *button,gpointer data)
{
		//g_signal_emit(G_OBJECT (ButtonLogin), "clicked",0);
		if(gtk_widget_is_focus (G_OBJECT(EditId)) ==1)
			gtk_widget_grab_focus (EditPwd);
		else
			gtk_button_clicked(G_OBJECT(ButtonLogin));
}
void on_entry_insert(GtkEditable *editable,gchar *new_text,gint new_text_length,gint *position,gpointer user_data)
{
	const char *text=gtk_entry_get_text(GTK_ENTRY(editable));
	if( (strcmp(new_text,"0")>=0 && strcmp(new_text,"9")<=0)||
		(strcmp(new_text,"A")>=0 && strcmp(new_text,"Z")<=0)||
		(strcmp(new_text,"a")>=0 && strcmp(new_text,"z")<=0) )
	{
		return;
	}
	else
	{
		gchar *result=g_utf8_strup(new_text,new_text_length);
		g_signal_handlers_block_by_func(editable,(gpointer)on_entry_insert,user_data);
		gtk_entry_set_text(GTK_ENTRY(editable),text);
		g_signal_handlers_unblock_by_func(editable,(gpointer)on_entry_insert,user_data);
		g_signal_stop_emission_by_name(editable,"insert_text");
		g_free(result);
	}
}

void on_setip_entry_insert(GtkEditable *editable,gchar *new_text,gint new_text_length,gint *position,gpointer user_data)
{
	const char *text=gtk_entry_get_text(GTK_ENTRY(editable));
	if( (strcmp(new_text,"0")>=0 && strcmp(new_text,"9")<=0)||
				strcmp(new_text,".") ==0  )
	{
		return;
	}
	else
	{
		gchar *result=g_utf8_strup(new_text,new_text_length);
		g_signal_handlers_block_by_func(editable,(gpointer)on_entry_insert,user_data);
		gtk_entry_set_text(GTK_ENTRY(editable),text);
		g_signal_handlers_unblock_by_func(editable,(gpointer)on_entry_insert,user_data);
		g_signal_stop_emission_by_name(editable,"insert_text");
		g_free(result);
	}
}

void on_setport_entry_insert(GtkEditable *editable,gchar *new_text,gint new_text_length,gint *position,gpointer user_data)
{
	/***/
	const char *text=gtk_entry_get_text(GTK_ENTRY(editable));
	//if( strcmp(new_text,"0")>=0 && strcmp(new_text,"9")<=0 || strcmp(new_text,".") ==0 )//
	if( strcmp(new_text,"0")>=0 && strcmp(new_text,"9")<=0 || 0 != memcmp( gtk_label_get_text(LabelPwd),"Port",4)  )//Port
	{
		return;
	}
	else
	{
		gchar *result=g_utf8_strup(new_text,new_text_length);
		g_signal_handlers_block_by_func(editable,(gpointer)on_entry_insert,user_data);
		gtk_entry_set_text(GTK_ENTRY(editable),text);
		g_signal_handlers_unblock_by_func(editable,(gpointer)on_entry_insert,user_data);
		g_signal_stop_emission_by_name(editable,"insert_text");
		g_free(result);
	}
	/****/
}

void UpdateSetLabel()
{
	gtk_label_set_text(LabelId,toutf8("�ʺ�:")); 
	gtk_label_set_text(LabelPwd,toutf8("����:"));
	gtk_widget_set_sensitive(ButtonIpStatic,1);
	gtk_widget_set_sensitive(ButtonIpAuto,1);
	gtk_widget_set_sensitive(ButtonIpMAC,1);
	gtk_widget_set_sensitive(EditPort,1);
	gtk_widget_hide(EditIp); 
	gtk_widget_hide(EditPort);
	gtk_widget_hide(ButtonSave);
	gtk_widget_hide(ButtonNext);  
	gtk_widget_hide(ButtonCancel);
	gtk_widget_hide(Hbox); 
	gtk_widget_show(ButtonSet);
	gtk_widget_show(ButtonIpSet); 
	gtk_widget_show(EditId); 
	gtk_widget_show(EditPwd);
	gtk_widget_show(ButtonLogin);
	gtk_widget_show(ButtonShutdown);	
}

void ButtonSave_clicked (GtkWidget *button,gpointer data)
{
	if( 0 == is_valid_ip(gtk_entry_get_text(EditIp)))//IP���
			return; 
	gtk_widget_set_sensitive(ButtonSave,0);
	FILE *fp=fopen("/lib/vdi_systems/settings.ini","wr+");
	add_config(fp, "Ip",gtk_entry_get_text(EditIp));
	add_config(fp, "Port",gtk_entry_get_text(EditPort));
	fclose(fp);
	UpdateSetLabel();	
	gtk_widget_set_sensitive(ButtonSave,1);
	g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#1BA1E2\" font_desc='18'>����ɹ������ڷ��أ���%d��</span>", FALSE, NULL); 
	return;
}

void ButtonCancel_clicked (GtkWidget *button,gpointer data)
{
	UpdateSetLabel();	
}

void LoginFailed(int sig)  
{  
    LoginFailedFlag= 1;  
}
/*******************************������־********************************************************/
int GetLogNum()//�鿴��־����
{
	 	FILE *stream;
	 	char recvBuf[20];  
    stream = popen("ls /opt/log/ |wc -l", "r"); 
    fread(recvBuf, sizeof(char), (size_t)stream, stream);  
    pclose(stream);
    clean_string(recvBuf); 
		return atoi(recvBuf);
}

int GetLogName( char recvBuf[][8] )
{
	 	FILE *stream;
	 	char buff[100];
    memset(buff,0,sizeof(buff));
    int i=2;
    int LogNum=GetLogNum()+2;
    for(;i<LogNum;i++)
    {
	    sprintf(buff,"ls /opt/log/ -lt|awk  'NR==%d''{print $9}'|cut -c1-8",i);  
	    stream = popen(buff, "r");//2-...�ļ���
	    memset(buff,0,sizeof(buff));
	    fread(recvBuf[i-2], sizeof(char), (size_t)stream, stream); 
	    pclose(stream);
  	}
		return 0;
}

GtkWidget *win_log; 
GtkTextBuffer *buffer;
void ButtonLogCancel_clicked (GtkWidget *button,GdkEventButton * event,gpointer data)
{
	//exit(0);
	gtk_widget_destroy(win_log);
} 

void ButtonLogGroup_clicked (GtkWidget *button,GdkEventButton * event,gpointer data)
{
		//printf("click %s\r\n",gtk_button_get_label(button));
		char buff[25];
    memset(buff,0,sizeof(buff));
    sprintf(buff,"cat /opt/log/%s.log",gtk_button_get_label(button));
		gchar *text;
		text=malloc(1000);
		FILE *stream;  
		stream = popen( buff , "r");  
		fread(text, sizeof(char), (size_t)stream, stream);  
		pclose(stream);
		
		//pthread_mutex_lock(&mutex);//��
		GtkTextIter start,end;
		//��û�������ʼ�ͽ���λ�õ�Iter
		gtk_text_buffer_get_bounds(GTK_TEXT_BUFFER(buffer),&start,&end);
		//�������
		gtk_text_buffer_delete(GTK_TEXT_BUFFER(buffer),&start,&end);
		//�����ı���������
		gtk_text_buffer_insert(GTK_TEXT_BUFFER(buffer),&start,toutf8(text),strlen(text));	
		free(text);
		//pthread_mutex_unlock(&mutex);//����
		//usleep(1000);
}

void ButtonLog_clicked (GtkWidget *button,GdkEventButton * event,gpointer data)
{
  if (event->button == 1)
  {   
		printf("left click\r\n");
  }
  else if( event->button == 3)
     printf ("right click\r\n");
  else if (event->button == 2)
  {
  	printf ("middle click\r\n");
  	win_log = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  	gtk_window_set_title(GTK_WINDOW(win_log), "win_log");//����
  	GtkWidget* fixed=gtk_fixed_new();
  	gtk_container_add(GTK_CONTAINER(win_log),fixed);
  	 	
	  int width=1600;
	  int height=900;
	  GtkWidget* ButtonSave=gtk_button_new_with_label(""); 
		//g_signal_connect (G_OBJECT (ButtonSave), "clicked", G_CALLBACK(ButtonSave_clicked),NULL);
		gtk_widget_set_size_request(ButtonSave, 90, 30);	
		//gtk_fixed_put(GTK_FIXED(fixed),ButtonSave,width/2-110,(height*2/3-128)); 
		
		GtkWidget* ButtonCancel=gtk_button_new_with_label(""); 
		g_signal_connect (G_OBJECT (ButtonCancel), "clicked", G_CALLBACK(ButtonLogCancel_clicked),NULL);
		gtk_widget_set_size_request(ButtonCancel, 90, 30);
		gtk_fixed_put(GTK_FIXED(fixed),ButtonCancel,width-90,0);
		
		gtk_widget_show(ButtonSave);
		gtk_widget_show(ButtonCancel);
		gtk_widget_set_name(ButtonSave, "ButtonSave");
		gtk_widget_set_name(ButtonCancel, "ButtonCancel");
	  gtk_widget_set_name(win_log, "window");
	 
	  buffer = gtk_text_buffer_new(NULL);	  
	  GtkWidget* GtkTxt=gtk_text_view_new_with_buffer(buffer);//gtk_text_view_new 
	  gtk_text_view_set_buffer(GtkTxt,buffer);
	  gtk_widget_show(GtkTxt);	  
	  gtk_widget_set_sensitive(GtkTxt,FALSE);
	  
	  GtkWidget *scrolled=gtk_scrolled_window_new(NULL,NULL);//�����������ڹ���
		gtk_fixed_put(GTK_FIXED(fixed),scrolled,100,5);	
		gtk_widget_show(scrolled);//��ʾ�������ڹ���
		gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled),GtkTxt);//���ı���ͼ���������������
	  gtk_widget_set_size_request(scrolled, 1000, 890);
	  //gtk_window_set_opacity(GtkTxt, 0);//͸����
	  //gtk_window_set_opacity(scrolled, 0);//͸����
	  
	  GtkWidget* Vbox = gtk_vbox_new(FALSE,0);
	  gtk_fixed_put(GTK_FIXED(fixed),Vbox,5,5);
	  gtk_widget_show(Vbox);   
	  int i;
	  GtkWidget* ButtonGroup[32];//����¼31����־ 1-31
	  ButtonGroup[0] = gtk_radio_button_new_with_label(NULL,toutf8(""));//����ʾ
	 
	  int LogNum=GetLogNum();
	  printf("LogNum=%d\r\n",LogNum);
	  char Buf[31][8];
	  char buff[8];
		memset(Buf,0,sizeof(Buf));
		GetLogName(Buf);
	  for(i=1;i<=LogNum;i++)
	  {     
			memcpy(buff,Buf[i-1],8);
			ButtonGroup[i] = gtk_radio_button_new_with_label(gtk_radio_button_get_group(GTK_RADIO_BUTTON(ButtonGroup[i-1])),toutf8(buff));	
			g_signal_connect (G_OBJECT (ButtonGroup[i]), "clicked", G_CALLBACK(ButtonLogGroup_clicked),NULL);
			gtk_box_pack_start(GTK_BOX(Vbox),ButtonGroup[i],FALSE,FALSE,3);
			gtk_widget_show(ButtonGroup[i]);			
	  }
  	if( 0< LogNum )
  	{
  		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ButtonGroup[1]),TRUE);
			gtk_widget_grab_focus (ButtonGroup[1]);  	
  	}  
	  gtk_widget_show(fixed); 
		gtk_window_fullscreen(win_log);
		gtk_widget_show(win_log);
  }
}
/*****************������־*******************/

int main(int argc, char *argv[]) 
{  
	printf("version 1.0.1\r\n");
	gtk_init(&argc,&argv);   
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_name(window, "window");
  gtk_window_set_decorated (GTK_WINDOW(window), TRUE);
  pthread_mutex_init(&mutex,NULL);
	fixed=gtk_fixed_new();
  signal(SIGCHLD,SIG_IGN);
  signal(SIGALRM,LoginFailed);
  if(!g_thread_supported()) 
	    g_thread_init(NULL);
	gdk_threads_init();  
	GdkScreen* screen;
	gint width, height;
	screen = gdk_screen_get_default();
	width = gdk_screen_get_width(screen);
	height = gdk_screen_get_height(screen);
	//printf("\r\n-----screen width: %d, height: %d -----\n", width, height);
	
	LabelTips=gtk_label_new("");
	gtk_widget_set_size_request(LabelTips,width, height);
	gtk_fixed_put(GTK_FIXED(fixed),LabelTips,0,0);
	//
	LabelId=gtk_label_new(toutf8("�ʺ�:")); 
	gtk_widget_set_size_request(LabelId, 90, 45);	
	gtk_widget_show(LabelId); 
	gtk_fixed_put(GTK_FIXED(fixed),LabelId,width*4/10-25,height*2/3-245);
	
	LabelPwd=gtk_label_new(toutf8("����:")); 
	gtk_widget_set_size_request(LabelPwd, 90, 45);
	gtk_widget_show(LabelPwd); 
	gtk_fixed_put(GTK_FIXED(fixed),LabelPwd,width*4/10-25,height*2/3-185);
	gtk_window_set_opacity(LabelId, 0.5); 
	gtk_window_set_opacity(LabelPwd, 0.5);
	
	EditId = gtk_entry_new();
	g_signal_connect (G_OBJECT (EditId), "changed", G_CALLBACK(EditId_Pwd_Signal),NULL);
	g_signal_connect (G_OBJECT (EditId), "activate", G_CALLBACK(EditId_Pwd_Enter),NULL);
	g_signal_connect(G_OBJECT(EditId),"insert-text",G_CALLBACK(on_entry_insert),NULL);
	gtk_widget_set_size_request(EditId, 280, 45);	
	gtk_entry_set_max_length(EditId,20);
	gtk_widget_show(EditId); 	
	gtk_fixed_put(GTK_FIXED(fixed),EditId,(width*4/10+55),(height*2/3-245));
	
	EditPwd = gtk_entry_new();//�����
	g_signal_connect (G_OBJECT (EditPwd), "changed", G_CALLBACK(EditId_Pwd_Signal),NULL);
	g_signal_connect (G_OBJECT (EditPwd), "activate", G_CALLBACK(EditId_Pwd_Enter),NULL);
	g_signal_connect(G_OBJECT(EditPwd),"insert-text",G_CALLBACK(on_entry_insert),NULL);
	gtk_widget_set_size_request(EditPwd, 280, 45);
	gtk_entry_set_max_length(EditPwd,20);
	gtk_entry_set_visibility(EditPwd,FALSE);	
	gtk_widget_show(EditPwd); 
	gtk_fixed_put(GTK_FIXED(fixed),EditPwd,(width*4/10+55),(height*2/3-185));
	gtk_window_set_opacity(EditId, 0.5); 
	gtk_window_set_opacity(EditPwd, 0.5); 
	
	ButtonLogin=gtk_button_new_with_label(""); 
	gtk_widget_set_sensitive(ButtonLogin,FALSE);
	g_signal_connect (G_OBJECT (ButtonLogin), "clicked", G_CALLBACK(ButtonLogin_clicked),NULL);
	gtk_widget_set_size_request(ButtonLogin, 90, 30);	
	gtk_widget_show(ButtonLogin); 
	//gtk_button_set_relief(ButtonLogin,GTK_RELIEF_NONE);
	//gtk_window_set_opacity(ButtonLogin, 0.5);
	gtk_widget_set_name(ButtonLogin, "ButtonLogin");
	gtk_fixed_put(GTK_FIXED(fixed),ButtonLogin,width/2-110,(height*2/3-128));
	
	ButtonShutdown=gtk_button_new_with_label(""); 
	g_signal_connect (G_OBJECT (ButtonShutdown), "clicked", G_CALLBACK(ButtonShutdown_clicked),NULL);
	gtk_widget_set_size_request(ButtonShutdown, 90, 30);	
	gtk_widget_show(ButtonShutdown); 
	//gtk_button_set_relief(ButtonShutdown,GTK_RELIEF_NONE);//
	//gtk_window_set_opacity(ButtonShutdown, 0.5);
	gtk_widget_set_name(ButtonShutdown, "ButtonShutdown");
	gtk_fixed_put(GTK_FIXED(fixed),ButtonShutdown,width/2+35,(height*2/3-128));
	
	
	ButtonSet=gtk_button_new_with_label("");
	g_signal_connect (G_OBJECT (ButtonSet), "clicked", G_CALLBACK(ButtonSet_clicked),NULL);
	gtk_widget_show(ButtonSet);
	gtk_widget_set_size_request(ButtonSet, 80, 5);
	gtk_button_set_relief(ButtonSet,GTK_RELIEF_NONE);
	gtk_window_set_opacity(ButtonSet, 0.35);
	if(width == 1920 && height == 1080) 
		gtk_fixed_put(GTK_FIXED(fixed),ButtonSet,width/2+60,(height*2/3-270));
	else //if(width == 1600 && height == 900 ) 
		gtk_fixed_put(GTK_FIXED(fixed),ButtonSet,width/2+52,(height*2/3-285));
	
	//----------------------���ý���--------------------------------//
	EditIp = gtk_entry_new();
	g_signal_connect (G_OBJECT (EditIp), "changed", G_CALLBACK(EditIpPort_Signal),NULL);
	g_signal_connect(G_OBJECT(EditIp),"insert-text",G_CALLBACK(on_setip_entry_insert),NULL);
	gtk_widget_set_size_request(EditIp, 280, 45);	
	gtk_entry_set_max_length(EditIp,20);
	gtk_fixed_put(GTK_FIXED(fixed),EditIp,(width*4/10+55),(height*2/3-245));
	
	EditPort = gtk_entry_new();
	g_signal_connect (G_OBJECT (EditPort), "changed", G_CALLBACK(EditIpPort_Signal),NULL);
	g_signal_connect(G_OBJECT(EditPort),"insert-text",G_CALLBACK(on_setport_entry_insert),NULL);
	gtk_widget_set_size_request(EditPort, 280, 45);
	gtk_entry_set_max_length(EditPort,6);	 
	gtk_fixed_put(GTK_FIXED(fixed),EditPort,(width*4/10+55),(height*2/3-185));
	gtk_window_set_opacity(EditIp, 0.5); 
	gtk_window_set_opacity(EditPort, 0.5);
	
	ButtonSave=gtk_button_new_with_label(""); 
	//gtk_widget_set_sensitive(ButtonSave,FALSE);
	g_signal_connect (G_OBJECT (ButtonSave), "clicked", G_CALLBACK(ButtonSave_clicked),NULL);
	gtk_widget_set_size_request(ButtonSave, 90, 30);	
	gtk_fixed_put(GTK_FIXED(fixed),ButtonSave,width/2-110,(height*2/3-128));
	
	ButtonCancel=gtk_button_new_with_label(""); 
	g_signal_connect (G_OBJECT (ButtonCancel), "clicked", G_CALLBACK(ButtonCancel_clicked),NULL);
	gtk_widget_set_size_request(ButtonCancel, 90, 30);	
	gtk_fixed_put(GTK_FIXED(fixed),ButtonCancel,width/2+35,(height*2/3-128));
	gtk_widget_set_name(ButtonSave, "ButtonSave");
	gtk_widget_set_name(ButtonCancel, "ButtonCancel");
	//-------------------------------------------------------------//
	
	//----------------------IP ����--------------------------------//
	ButtonIpSet=gtk_button_new_with_label("");
	g_signal_connect (G_OBJECT (ButtonIpSet), "clicked", G_CALLBACK(ButtonIpSet_clicked),NULL);
	gtk_widget_show(ButtonIpSet);
	gtk_widget_set_size_request(ButtonIpSet, 80, 5);
	gtk_button_set_relief(ButtonIpSet,GTK_RELIEF_NONE);
	gtk_window_set_opacity(ButtonIpSet, 0.35);
	if(width == 1920 && height == 1080) 
		gtk_fixed_put(GTK_FIXED(fixed),ButtonIpSet,width/2-38,(height*2/3-270));
	else //if(width == 1600 && height == 900 ) 
		gtk_fixed_put(GTK_FIXED(fixed),ButtonIpSet,width/2-50,(height*2/3-285));
	
	ButtonNext=gtk_button_new_with_label(""); 
	g_signal_connect (G_OBJECT (ButtonNext), "clicked", G_CALLBACK(ButtonNext_clicked),NULL);
	gtk_widget_set_size_request(ButtonNext, 90, 30);	
	gtk_widget_hide(ButtonNext); 
	gtk_widget_set_name(ButtonNext, "ButtonNext");
	gtk_fixed_put(GTK_FIXED(fixed),ButtonNext,width/2-110,(height*2/3-128));
	
	//��ѡ����	    
	ButtonIpAuto = gtk_radio_button_new_with_label(NULL,toutf8("��̬��ȡ"));  
	//ButtonGroup1 = gtk_radio_button_get_group(GTK_RADIO_BUTTON(ButtonIpAuto));  
	ButtonIpStatic = gtk_radio_button_new_with_label(gtk_radio_button_get_group(GTK_RADIO_BUTTON(ButtonIpAuto)),toutf8("��̬����"));
	//ButtonGroup2 = gtk_radio_button_get_group(GTK_RADIO_BUTTON(ButtonIpStatic)); 
	ButtonIpMAC = gtk_radio_button_new_with_label(gtk_radio_button_get_group(GTK_RADIO_BUTTON(ButtonIpStatic)),toutf8("�鿴Ӳ��"));  
	
	g_signal_connect (G_OBJECT (ButtonIpAuto), "clicked", G_CALLBACK(ButtonGroup_clicked),NULL);
	g_signal_connect (G_OBJECT (ButtonIpStatic), "clicked", G_CALLBACK(ButtonGroup_clicked),NULL);
	g_signal_connect (G_OBJECT (ButtonIpMAC), "clicked", G_CALLBACK(ButtonGroup_clicked),NULL);
	
	Hbox = gtk_hbox_new(FALSE,0);   
	gtk_box_pack_start(GTK_BOX(Hbox),ButtonIpAuto,FALSE,FALSE,10);//���10  
	gtk_box_pack_start(GTK_BOX(Hbox),ButtonIpStatic,FALSE,FALSE,10); 
	gtk_box_pack_start(GTK_BOX(Hbox),ButtonIpMAC,FALSE,FALSE,10);
	gtk_widget_show(ButtonIpAuto);
	gtk_widget_show(ButtonIpStatic);
	gtk_widget_show(ButtonIpMAC);
	if(width == 1920 && height == 1080)  
		gtk_fixed_put(GTK_FIXED(fixed),Hbox,width/2-145,height*2/3-220);//1080P
	else //if(width == 1600 && height == 900)
		gtk_fixed_put(GTK_FIXED(fixed),Hbox,width/2-110,height*2/3-230);
		
	//-------------------------------------------------------------//
	
	/*************************************************************
	char MACBuff[25];
	memset(MACBuff,0,sizeof(MACBuff));
	GetMAC(MACBuff);
	LabelMAC=gtk_label_new(toutf8(MACBuff)); 
	gtk_widget_set_size_request(LabelMAC, 90, 45);
	//gtk_widget_show(LabelMAC); 
	//gtk_fixed_put(GTK_FIXED(fixed),LabelMAC,width/2+50,height*2/3-150);
	gtk_fixed_put(GTK_FIXED(fixed),LabelMAC,0,0);
	gtk_window_set_opacity(LabelMAC, 0.5); /***/
	//-------------------------------------------------------------//
	
	/************����˫����ť***********************************/
	GtkWidget *ButtonTest=gtk_button_new_with_label("");
	gtk_widget_set_size_request(ButtonTest, 30, 10);
	gtk_button_set_relief(ButtonTest,GTK_RELIEF_NONE);
	gtk_fixed_put(GTK_FIXED(fixed),ButtonTest,0,0);
	gtk_window_set_opacity(ButtonTest, 0);//͸����
	gtk_widget_show(ButtonTest);  //clicked activate
	gtk_widget_set_events(ButtonTest, GDK_EXPOSURE_MASK | GDK_LEAVE_NOTIFY_MASK| GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK| GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK);  
	//g_signal_connect (GTK_WIDGET(ButtonTest), "button_press_event", G_CALLBACK(ButtonLog_clicked), NULL);
	/***********************************************************/
	
  GtkCssProvider *provider = gtk_css_provider_new ();
	GdkDisplay *display = gdk_display_get_default ();
	GdkScreen *MyScreen = gdk_display_get_default_screen (display);
	

	gtk_style_context_add_provider_for_screen(MyScreen,
				                      GTK_STYLE_PROVIDER(provider),
				                      GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
	if(width == 1920 && height == 1080) 
	{		                      
			gtk_css_provider_load_from_data(GTK_CSS_PROVIDER(provider), 			
																	"#window{"																	
																	"background-image: url('/lib/vdi_systems/image/bj_1920_1080.jpg');"																	
																	"}"	
																	"#ButtonLogin{"
																	"background-image: url('/lib/vdi_systems/image/Login.png');"
																	"}"
																	"#ButtonShutdown{"
																	"background-image: url('/lib/vdi_systems/image/Shutdown.png');" 
																	"}"
																	"#ButtonSave{"
																	"background-image: url('/lib/vdi_systems/image/Save.png');" 
																	"}"
																	"#ButtonNext{"
																	"background-image: url('/lib/vdi_systems/image/Next.png');" 
																	"}"
																	"#ButtonCancel{"
																	"background-image: url('/lib/vdi_systems/image/Cancel.png');" 
																	"}"
																	, -1, NULL);
	}
	else //if(width == 1600 && height == 900)
	{
			gtk_css_provider_load_from_data(GTK_CSS_PROVIDER(provider), 			
																	"#window{"																	
																	"background-image: url('/lib/vdi_systems/image/bj_1600_900.jpg');"																	
																	"}"	
																	"#ButtonLogin{"
																	"background-image: url('/lib/vdi_systems/image/Login.png');"
																	"}"
																	"#ButtonShutdown{"
																	"background-image: url('/lib/vdi_systems/image/Shutdown.png');" 
																	"}"
																	"#ButtonNext{"
																	"background-image: url('/lib/vdi_systems/image/Next.png');" 
																	"}"
																	"#ButtonSave{"
																	"background-image: url('/lib/vdi_systems/image/Save.png');" 
																	"}"
																	"#ButtonCancel{"
																	"background-image: url('/lib/vdi_systems/image/Cancel.png');" 
																	"}"
																	, -1, NULL);
	}																	
	gtk_widget_grab_focus (EditId);
  gtk_container_add(GTK_CONTAINER(window),fixed);
	gtk_widget_show(fixed); 
	gtk_widget_show(window); 
	gtk_window_fullscreen(window);
	//system("echo linkosky |sudo -S /lib/vdi_systems/keyconfig &");//
	gdk_threads_enter(); 
	gtk_init(&argc, &argv);
	gtk_main();
	gdk_threads_leave();
	return 0;
}
void SetGrabFocus()
{
		if( gtk_entry_get_text_length(EditId)>0 )
		{
			gdk_threads_enter();
			gtk_widget_grab_focus (EditPwd);
			gdk_threads_leave();
		}
		else
		{
				gdk_threads_enter();
				gtk_widget_grab_focus (EditId);
				gdk_threads_leave();
		}
}

void* Pthread_LabelUpdateText(void *argv)
{
	//printf("Pthread_LabelUpdateText :%s\r\n",argv);
	pthread_mutex_lock(&mutex);
	gdk_threads_enter();
	gtk_widget_hide(ButtonSet); 
	gtk_widget_hide(ButtonIpSet);
	gtk_widget_hide(LabelId); 
	gtk_widget_hide(LabelPwd);
	gtk_widget_hide(EditId); 
	gtk_widget_hide(EditPwd);
	gtk_widget_hide(ButtonLogin);
	gtk_widget_hide(ButtonShutdown);
	
	gdk_threads_leave();
	static int i;
	memset(buff,0,sizeof(buff));
	gdk_threads_enter();
	gtk_widget_show(LabelTips);
	gdk_threads_leave();
	for(i=3;i>0;i--)
	{
		sprintf(buff,argv,i);
		gdk_threads_enter();
		gtk_label_set_markup(GTK_LABEL(LabelTips),toutf8(buff));
		gdk_threads_leave();
		sleep(1);
	}	
	gdk_threads_enter();
	gtk_widget_hide(LabelTips);
	gtk_widget_show(ButtonSet); 
	gtk_widget_show(ButtonIpSet); 
	gtk_widget_show(LabelId); 
	gtk_widget_show(LabelPwd);
	gtk_widget_show(EditId); 
	gtk_widget_show(EditPwd);
	gtk_widget_show(ButtonLogin);
	gtk_widget_show(ButtonShutdown);
	gdk_threads_leave(); 
	SetGrabFocus();
	pthread_mutex_unlock(&mutex);
	return NULL;
}

void* Pthread_LoginUpdateText(void *argv)
{
	pthread_mutex_lock(&mutex);
	gdk_threads_enter();
	gtk_widget_hide(ButtonSet);
	gtk_widget_hide(LabelId); 
	gtk_widget_hide(LabelPwd);
	gtk_widget_hide(EditId); 
	gtk_widget_hide(EditPwd);
	gtk_widget_hide(ButtonLogin);
	gtk_widget_hide(ButtonShutdown);
	gtk_widget_show(LabelTips);
	gdk_threads_leave();
	int i;
	//for(i=1;i<11;i++)
	for(i=1;i<60;i++)
	{
		memset(buff,0,sizeof(buff));
		//sprintf(buff,"<span foreground=\"#1BA1E2\" font_desc='18'>���ڵ�¼�����Ժ�...����%d��</span>",i);
		
		if(1)
		{
			if( i%5 ==0)
			 sprintf(buff,"<span foreground=\"#1BA1E2\" font_desc='18'>�������ӣ����Ժ� .</span>");			
			if( i%5 ==1)
			 sprintf(buff,"<span foreground=\"#1BA1E2\" font_desc='18'>�������ӣ����Ժ� ..</span>");
			if( i%5 ==2)
			 sprintf(buff,"<span foreground=\"#1BA1E2\" font_desc='18'>�������ӣ����Ժ� ...</span>");
			if( i%5 ==3)
			 sprintf(buff,"<span foreground=\"#1BA1E2\" font_desc='18'>�������ӣ����Ժ� ....</span>");
			if( i%5 ==4)
			 sprintf(buff,"<span foreground=\"#1BA1E2\" font_desc='18'>�������ӣ����Ժ� .....</span>");
		}
		gdk_threads_enter();
		gtk_label_set_markup(GTK_LABEL(LabelTips),toutf8(buff));
		gdk_threads_leave();
		if(LoginFailedFlag)
		{
			LoginFailedFlag=0;
			for(i=3;i>0;i--)
			{
				memset(buff,0,sizeof(buff));
				sprintf(buff,"<span foreground=\"#FF0000\" font_desc='18'>�����������󣬵�¼ʧ�ܣ����Ժ����ԣ���%d��</span>",i);
				gdk_threads_enter();
				gtk_label_set_markup(GTK_LABEL(LabelTips),toutf8(buff));
				gdk_threads_leave();
				sleep(1);
			}
			break;
		}
		sleep(1);
	}
	gdk_threads_enter();
	gtk_widget_hide(LabelTips);
	gtk_widget_show(LabelId); 
	gtk_widget_show(LabelPwd);
	gtk_widget_show(EditId); 
	gtk_widget_show(EditPwd);
	gtk_widget_show(ButtonLogin);
	gtk_widget_show(ButtonShutdown);
	gtk_widget_show(ButtonSet);
	gdk_threads_leave();
	SetGrabFocus();
	pthread_mutex_unlock(&mutex);
	return NULL;
}


void* Pthread_CheckConnect(void *argv)
{
		int i=1;
		static flag=0;
		if(flag == 1)
			return 0;
		flag=1; 
		printf("Pthread_CheckConnect\r\n");	
		for(;;)
		{
	    if(CheckConnect(argv,5))   
	    {
	      printf("Network is not up\r\n");
	      i++; 
	    } 
	    else  
	    {   
	      //printf("Network is up\r\n");
	      i=1;
	    } 
		  if(i>5)
		  {
		  	system("echo linkosky |sudo -S killall spicy");
		  	g_thread_create((GThreadFunc)Pthread_LabelUpdateText,"<span foreground=\"#FF0000\" font_desc='18'>���ӶϿ��������µ�¼����%d��</span>", FALSE, NULL); 					
		  	flag=0;
		  	return 0; 	  
	  	}
	  	 sleep(5);
  	}
}

int CheckConnect(char *dst, int cnt)  
{  
    int i = 0;  
    FILE *stream;  
    char recvBuf[16] = {0};  
    char cmdBuf[256] = {0};  
    if (NULL == dst || cnt <= 0)  
        return -1;  
    sprintf(cmdBuf, "ping %s -c %d -i 0.2 -w 1| grep time= | wc -l", dst, cnt);  
    stream = popen(cmdBuf, "r");  
    fread(recvBuf, sizeof(char), sizeof(recvBuf)-1, stream);  
    pclose(stream);  
    if (atoi(recvBuf) > 0)  
    	return 0;  
    return -1;  
}
